# Ennxi 的主题插件

AstrBot 插件

A template plugin for AstrBot plugin feature

# 支持

# [Bot 网站](https:ennxi.xyz)
可以使用
/菜单 "对应数字"使用指令
